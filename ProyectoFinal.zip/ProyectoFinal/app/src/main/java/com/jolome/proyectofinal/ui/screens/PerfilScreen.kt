package com.jolome.proyectofinal.ui.screens

import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import com.jolome.proyectofinal.navigation.Routes

@Composable
fun PerfilScreen(navController: NavController){

}