package com.jolome.proyectofinal.navigation

sealed class Routes(val route:String) {
    object SplashScreen: Routes("splash_screen")
    object Registro: Routes("Registro")
    object InicioSesion: Routes("InicioSesion")
    object MainSrcreen: Routes("MainScreen")
    object Screeen: Routes("Screeen")
    object PerfilScreen: Routes("PerfilScreen")

}