package com.jolome.proyectofinal.ui.screens.comunes

import androidx.compose.runtime.Composable
import androidx.navigation.NavController

@Composable
fun MainScreen(navController: NavController){

}